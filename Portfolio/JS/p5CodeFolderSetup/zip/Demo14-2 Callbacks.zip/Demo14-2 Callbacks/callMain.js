/**
 * Julia Hotaling
 * Demo/ICE callbacks 14/25/18
 * demo of the callack function
 **/
"use strict"

let splatBt;
let linesBt;

let xLoc;
let yLoc;

let hues = [];

function setup() {
    createCanvas(400, 300);
    colorMode(HSB);
    noStroke();
    background(0);

    splatBt = createButton("Splat!");
    splatBt.position(width + 20, 20);
    splatBt.mouseClicked(setLoc);
    
    linesBt = createButton("Do Stuff");
    linesBt.position(width + 20, 60);
    linesBt.mouseClicked(doStuff);

    for (let i = 0; i < 120; i++) {
        hues.push(i * 3);
    }
}

function draw() {
    alterHues();
    drawDisk();
}

function setLoc() {
    xLoc = random(60, width - 60);
    yLoc = random(60, height - 60);
}

function drawDisk() {
//    for (let i = 0; i < hues.length; i++) {
//        let index = hues.length - i - 1;
//        fill(hues[index], 100, 100);
//        ellipse(xLoc, yLoc, index, index);
//    }

    hues.forEach(drawOne);
}

function drawOne(hue, i) {
    let index = hues.length - i - 1;
    fill(hue, 100, 100);
    ellipse(xLoc, yLoc, index, index);
}

function alterHues() {
    for (let i = 0; i < hues.length; i++) {
        hues[i] = (hues[i] + 1) % 360;
    }
}

function doStuff() {
    stroke(random(360), 100, 100);
    repeatFn(10, doLine);
    repeatFn(5, doBox);
}

function doLine() {
    line(random(width), random(height), random(width), random(height));
}

function doBox() {
    noStroke();
    fill(random(360), 100, 100, .5);
    rect(random(width/2), random(height/2), random(width/2), random(height/2));
}

function repeatFn(n, callback) {
    for (let i = 0; i < n; i++) {
        callback();
    }
}

