/**
 * Demo3-1 Stack and Queue example - by Al Biles
 * Main driver to test MyStack and MyQueue classes
 * This first version implements & tests the MyStack class
 *
 * ICE 3-1 is to Display a square whose hue value is
 * the value peing pushed onto or popped from the stack.
 * Squares for pushed values should appear to the left
 * of the stack, and popped values should appear to the
 * right.
 */

let s1;				// A MyStack to play with
let num = 0;	// Counter for adding and deleting numbers
let dir = 1;	// Direction of test:  1 add, -1 delete

function setup() {
	// Window 360 tall to map to Hue values in HSB easily
	createCanvas(200, 360);
	colorMode(HSB);
	
	//Create the actual MyStack object
	s1 = new MyStack();
	
	//s1.myPush(100);			// Initial test of push & pop
	//let x = s1.myPop();
	//print(x);
}

function draw() {
	background(100);			// Clear canvas to white
	testStk();
}

// Test the MyStack by pushing until full,
// then popping until empty, then pushing until...
function testStk() {
	// Get current length of MyStack
	let sLeng = s1.myLeng();
	
	// Flip directions at stack/canvas limits
	if (sLeng >= height)
		dir = -1;					// Start popping when hit top
	else if (sLeng <= 0)
		dir = 1;					// Start pushing when hit bottom
	
	// Based on the direction either push or pop an item
	// and then display the entire stack
	if (dir > 0) {
		s1.myPush(num);
		s1.display();
		num++;
		// Code for ICE 3-1 goes here
	}
	else {
		let hue = s1.myPop();
		s1.display();
		num--;
		// Code for ICE 3-1 goes here
	}
}
