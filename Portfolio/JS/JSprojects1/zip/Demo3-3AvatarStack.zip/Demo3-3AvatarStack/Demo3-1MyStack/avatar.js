/* Avatar class -  Julia Hotaling
 * Base class for a hierarchy of shape-based avatars
 * Used in the AvStack class, which stores a collection 
 * of currently active avatars on the canvas.
 */

class Avatar {

    constructor() {
        this.xOff = random(100);
        this.xInc = 0.006;
        this.x = noise(this.xOff) * width;
        
        this.yOff = random(100);
        this.yInc = 0.006;
        this.y = noise(this.yOff) * height;
    }

    move() {
        this.xOff = this.xOff + this.xInc;
        this.x = noise(this.xOff) * width;
        
        this.yOff = this.yOff + this.yInc;
        this.y = noise(this.yOff) * height;
    }

    display() {
        stroke(100);
        strokeWeight(10)
        point(this.x, this.y);
    }
}
